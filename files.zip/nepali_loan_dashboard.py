import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

# ─── Page config ───────────────────────────────────────────────
st.set_page_config(
    page_title="ऋण चुक्ता जोखिम ड्यासबोर्ड",
    page_icon="🏦",
    layout="wide",
)

# ─── Custom CSS ────────────────────────────────────────────────
st.markdown("""
<style>
    .main { background-color: #f8f9fa; }
    .block-container { padding-top: 1.5rem; padding-bottom: 1rem; }
    .metric-card {
        background: white;
        border-radius: 10px;
        padding: 16px 20px;
        border: 0.5px solid #e0e0e0;
    }
    .stMetric { background: white; border-radius: 10px; padding: 12px; }
    h1 { font-size: 22px !important; }
    .badge-high { background:#FCEBEB; color:#A32D2D; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:500; }
    .badge-med  { background:#FAEEDA; color:#633806; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:500; }
    .badge-low  { background:#EAF3DE; color:#27500A; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:500; }
</style>
""", unsafe_allow_html=True)

# ─── Data ──────────────────────────────────────────────────────
MONTHS_NP = ["श्रावण","भाद्र","आश्विन","कार्तिक","मंसिर","पौष",
             "माघ","फाल्गुन","चैत्र","बैशाख","जेठ","असार"]

SECTOR_DATA = {
    "सबै ऋण":       {"npl":4.8, "atrisk":1240, "total":25800, "recovery":68, "avg_lakh":4.2,
                     "high":18, "med":47, "low":35,
                     "trend":[3.8,4.0,4.1,4.3,4.5,4.4,4.6,4.7,4.8,4.9,4.8,4.8]},
    "व्यक्तिगत":    {"npl":4.8, "atrisk":420,  "total":9200,  "recovery":71, "avg_lakh":1.8,
                     "high":14, "med":52, "low":34,
                     "trend":[3.2,3.5,3.8,4.0,4.2,4.4,4.5,4.7,4.8,4.9,5.0,4.8]},
    "व्यापारिक":    {"npl":6.1, "atrisk":580,  "total":9500,  "recovery":62, "avg_lakh":8.4,
                     "high":24, "med":44, "low":32,
                     "trend":[4.5,4.8,5.0,5.2,5.6,5.8,6.0,6.1,6.2,6.0,6.1,6.1]},
    "आवास":          {"npl":2.3, "atrisk":240,  "total":7100,  "recovery":80, "avg_lakh":12.0,
                     "high":8,  "med":38, "low":54,
                     "trend":[2.0,2.0,2.1,2.2,2.2,2.3,2.3,2.4,2.3,2.3,2.3,2.3]},
}

SECTOR_RISK = {
    "कृषि":             7.2,
    "खुद्रा व्यापार":   5.8,
    "व्यक्तिगत":        4.8,
    "घरजग्गा":          3.2,
    "उत्पादन":          2.8,
    "तलबी कर्मचारी":    1.4,
}

AGE_DATA = {
    "उमेर":   ["१८-२५", "२६-३५", "३६-४५", "४६-५५", "५६+"],
    "दर (%)": [6.2,     4.1,     3.8,     5.2,     7.8],
}

AT_RISK_TABLE = pd.DataFrame({
    "ऋणी":       ["श्रेष्ठ ट्रेडर्स", "राम बहादुर क.", "सनराइज प्रालि", "गीता राई", "हिमाल निर्माण"],
    "क्षेत्र":   ["खुद्रा", "कृषि", "उत्पादन", "व्यक्तिगत", "घरजग्गा"],
    "रकम (लाख)": [18, 6.5, 42, 3.2, 85],
    "जोखिम":     ["उच्च", "उच्च", "मध्यम", "मध्यम", "न्यून"],
})

# ─── Sidebar ───────────────────────────────────────────────────
st.sidebar.title("🏦 नेपाल बैंक")
st.sidebar.markdown("**ऋण जोखिम विश्लेषण प्रणाली**")
st.sidebar.markdown("---")
selected = st.sidebar.radio("ऋण प्रकार छान्नुस्:", list(SECTOR_DATA.keys()), index=0)

st.sidebar.markdown("---")
st.sidebar.markdown("**आर्थिक वर्ष:** २०८०/८१")
st.sidebar.markdown("**अद्यावधिक:** असार २०८१")

npl_thresh = st.sidebar.slider("NPL चेतावनी सीमा (%)", min_value=1.0, max_value=10.0, value=5.0, step=0.5)

# ─── Data for selected filter ──────────────────────────────────
d = SECTOR_DATA[selected]

# ─── Header ────────────────────────────────────────────────────
st.title("🏦 ऋण चुक्ता जोखिम ड्यासबोर्ड")
st.caption(f"**ऋण प्रकार:** {selected} &nbsp;|&nbsp; **आर्थिक वर्ष:** २०८०/८१")

if d["npl"] >= npl_thresh:
    st.error(f"⚠️ सतर्कता: NPL अनुपात ({d['npl']}%) तपाईंको सीमा ({npl_thresh}%) भन्दा माथि छ!")

st.markdown("---")

# ─── KPI Cards ─────────────────────────────────────────────────
k1, k2, k3, k4 = st.columns(4)

with k1:
    delta_color = "inverse" if d["npl"] >= npl_thresh else "normal"
    st.metric("खराब ऋण अनुपात (NPL)", f"{d['npl']}%", "+०.६%", delta_color=delta_color)

with k2:
    st.metric("जोखिममा रहेका ऋण", f"{d['atrisk']:,}", f"{d['total']:,} मध्येबाट")

with k3:
    st.metric("असुली दर", f"{d['recovery']}%", f"लक्ष्य: ७०%",
              delta_color="normal" if d["recovery"] >= 70 else "inverse")

with k4:
    st.metric("औसत ऋण रकम", f"रु {d['avg_lakh']} लाख")

st.markdown("---")

# ─── Row 1: Bar chart + Donut ──────────────────────────────────
col1, col2 = st.columns(2)

with col1:
    st.subheader("क्षेत्रगत जोखिम दर")
    sector_df = pd.DataFrame({
        "क्षेत्र": list(SECTOR_RISK.keys()),
        "जोखिम दर (%)": list(SECTOR_RISK.values()),
    }).sort_values("जोखिम दर (%)", ascending=True)

    colors = ["#1D9E75" if v < 3 else "#EF9F27" if v < 6 else "#E24B4A"
              for v in sector_df["जोखिम दर (%)"]]

    fig_bar = px.bar(
        sector_df, x="जोखिम दर (%)", y="क्षेत्र", orientation="h",
        color="जोखिम दर (%)",
        color_continuous_scale=["#1D9E75","#EF9F27","#E24B4A"],
        range_color=[0, 10],
        text="जोखिम दर (%)",
    )
    fig_bar.update_traces(texttemplate="%{text}%", textposition="outside")
    fig_bar.update_layout(
        height=280, margin=dict(l=0,r=30,t=10,b=10),
        showlegend=False, coloraxis_showscale=False,
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(showgrid=False, visible=False),
        yaxis=dict(showgrid=False),
    )
    st.plotly_chart(fig_bar, use_container_width=True)

with col2:
    st.subheader("जोखिम स्कोर वितरण")
    fig_donut = go.Figure(data=[go.Pie(
        labels=["उच्च जोखिम", "मध्यम जोखिम", "न्यून जोखिम"],
        values=[d["high"], d["med"], d["low"]],
        hole=0.65,
        marker_colors=["#E24B4A", "#EF9F27", "#1D9E75"],
        textinfo="label+percent",
        textfont_size=12,
    )])
    fig_donut.update_layout(
        height=280, margin=dict(l=0,r=0,t=10,b=10),
        showlegend=False,
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        annotations=[dict(text=f"<b>{d['high']+d['med']+d['low']}%</b><br>कुल", x=0.5, y=0.5,
                          font_size=14, showarrow=False)]
    )
    st.plotly_chart(fig_donut, use_container_width=True)

# ─── Row 2: Trend line ─────────────────────────────────────────
st.subheader("मासिक खराब ऋण प्रवृत्ति — आ.व. २०८०/८१")

trend_df = pd.DataFrame({"महिना": MONTHS_NP, "NPL (%)": d["trend"]})
fig_trend = px.line(
    trend_df, x="महिना", y="NPL (%)",
    markers=True, line_shape="spline",
    color_discrete_sequence=["#E24B4A"],
)
fig_trend.add_hline(y=npl_thresh, line_dash="dash", line_color="#EF9F27",
                    annotation_text=f"सीमा: {npl_thresh}%", annotation_position="top right")
fig_trend.update_traces(fill="tozeroy", fillcolor="rgba(226,75,74,0.08)")
fig_trend.update_layout(
    height=220, margin=dict(l=0,r=20,t=10,b=10),
    plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
    xaxis=dict(showgrid=False), yaxis=dict(showgrid=True, gridcolor="#f0f0f0", ticksuffix="%"),
)
st.plotly_chart(fig_trend, use_container_width=True)

# ─── Row 3: Age chart + Risk table ────────────────────────────
col3, col4 = st.columns(2)

with col3:
    st.subheader("उमेर समूहअनुसार जोखिम दर")
    age_df = pd.DataFrame(AGE_DATA)
    age_colors = ["#E24B4A","#1D9E75","#1D9E75","#EF9F27","#E24B4A"]
    fig_age = px.bar(
        age_df, x="उमेर", y="दर (%)",
        color="उमेर",
        color_discrete_sequence=age_colors,
        text="दर (%)",
    )
    fig_age.update_traces(texttemplate="%{text}%", textposition="outside", showlegend=False)
    fig_age.update_layout(
        height=260, margin=dict(l=0,r=10,t=10,b=10),
        showlegend=False,
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(showgrid=False), yaxis=dict(showgrid=True, gridcolor="#f0f0f0", ticksuffix="%"),
    )
    st.plotly_chart(fig_age, use_container_width=True)

with col4:
    st.subheader("उच्च जोखिमका ऋणहरू")

    def risk_badge(val):
        if val == "उच्च":
            return "🔴 उच्च"
        elif val == "मध्यम":
            return "🟡 मध्यम"
        return "🟢 न्यून"

    display_df = AT_RISK_TABLE.copy()
    display_df["जोखिम"] = display_df["जोखिम"].apply(risk_badge)
    display_df["रकम (लाख)"] = display_df["रकम (लाख)"].apply(lambda x: f"रु {x} लाख")

    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True,
        height=260,
    )

# ─── Footer ────────────────────────────────────────────────────
st.markdown("---")
st.caption("ड्यासबोर्ड बनाउनेः Data Engineering Portfolio Project · Python + Streamlit + Plotly")
